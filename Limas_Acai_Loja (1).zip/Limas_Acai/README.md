# Lima´s Açaí — Landing page

Site responsivo de uma loja de açaí feito com HTML, CSS e JavaScript.

## Como abrir
1. Extraia o arquivo ZIP.
2. Abra a pasta `Limas_Acai`.
3. Clique duas vezes em `index.html` para abrir no navegador.

Não é necessário instalar nada. É recomendável ter internet para carregar as fontes e fotos externas.

## Configure o WhatsApp da loja
1. Abra `script.js` em um editor de texto ou VS Code.
2. No começo do arquivo, encontre `const WHATSAPP_NUMBER = "5521999999999";`.
3. Troque pelo número real da loja com código do país + DDD + número, somente dígitos. Exemplo fictício: `5511988887777`.
4. Salve o arquivo. O botão de pedido abrirá o WhatsApp com os itens selecionados.

## Personalize
- Produtos, descrições e preços: edite o HTML em `index.html`.
- Cores, espaçamento e aparência: edite `style.css`.
- Carrinho simples e integração do WhatsApp: edite `script.js`.

## Publicar gratuitamente no GitHub Pages
1. Crie um repositório no GitHub.
2. Envie `index.html`, `style.css`, `script.js` e `README.md` para a raiz do repositório.
3. No repositório, abra **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/(root)`, depois salve.
6. Aguarde a publicação e use o endereço informado pelo GitHub Pages.

As imagens e fontes são carregadas de serviços externos, então precisam de internet.
