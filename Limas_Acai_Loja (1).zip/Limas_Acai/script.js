// Lima´s Açaí — personalize aqui o número do WhatsApp da loja.
// Use código do país + DDD + número, somente dígitos. Ex.: 5521999999999
const WHATSAPP_NUMBER = "5521999999999";

const cart = [];
const cartCount = document.querySelector("#cart-count");
const toast = document.querySelector("#toast");
let toastTimer;

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
}

document.querySelectorAll(".add-button").forEach((button) => {
  button.addEventListener("click", () => {
    cart.push({ name: button.dataset.product, price: Number(button.dataset.price) });
    cartCount.textContent = cart.length;
    showToast(`${button.dataset.product} adicionado ao seu pedido!`);
  });
});

function formatPrice(value) {
  return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function orderMessage() {
  if (cart.length === 0) return "Olá! Gostaria de conhecer o cardápio da Lima´s Açaí.";
  const lines = cart.map(item => `• ${item.name} — ${formatPrice(item.price)}`);
  const total = cart.reduce((sum, item) => sum + item.price, 0);
  return `Olá! Quero fazer um pedido na Lima´s Açaí:\n${lines.join("\n")}\n\nTotal estimado: ${formatPrice(total)}\nPodem me informar as opções de entrega?`;
}

function openWhatsApp() {
  if (!/^\d{12,13}$/.test(WHATSAPP_NUMBER)) {
    showToast("Configure o número do WhatsApp no arquivo script.js.");
    return;
  }
  window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(orderMessage())}`, "_blank", "noopener,noreferrer");
}

document.querySelector("#whatsapp-order").addEventListener("click", openWhatsApp);
document.querySelector("#view-cart").addEventListener("click", () => {
  if (cart.length === 0) {
    showToast("Seu pedido está vazio. Toque no + para adicionar um açaí.");
    return;
  }
  const total = cart.reduce((sum, item) => sum + item.price, 0);
  const summary = cart.map(item => `${item.name} (${formatPrice(item.price)})`).join(", ");
  showToast(`Pedido: ${summary}. Total: ${formatPrice(total)}. Clique em “Pedir pelo WhatsApp” para enviar.`);
  document.querySelector("#whatsapp-order").scrollIntoView({ behavior: "smooth", block: "center" });
});

const menuToggle = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav");
menuToggle.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(open));
  menuToggle.textContent = open ? "✕" : "☰";
});
nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  nav.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
  menuToggle.textContent = "☰";
}));
document.querySelector("#year").textContent = new Date().getFullYear();
